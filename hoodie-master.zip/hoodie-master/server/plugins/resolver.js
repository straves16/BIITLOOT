module.exports = require.resolve
