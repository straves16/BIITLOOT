module.exports = register

function register (server, options, next) {
  return next()
}
